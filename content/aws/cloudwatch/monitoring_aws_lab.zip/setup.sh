#!/usr/bin/env bash
set -e

echo "🔧 Starting LocalStack..."
docker run --rm -d --name localstack -p 4566:4566 localstack/localstack
sleep 10

echo "📦 Packaging Lambdas..."
zip -j lambda_producer.zip lambda_producer.py
zip -j lambda_consumer.zip lambda_consumer.py

echo "🌱 Initializing Terraform..."
terraform init

echo "✅ Applying Terraform..."
terraform apply -auto-approve

echo "🎉 Lab setup complete!"
