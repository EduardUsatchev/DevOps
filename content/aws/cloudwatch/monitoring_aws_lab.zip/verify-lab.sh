#!/usr/bin/env bash
set -e

AWS="aws --endpoint-url=http://localhost:4566"

echo "🔍 Checking SQS queue..."
$AWS sqs get-queue-url --queue-name lab-sqs-queue

echo "🚀 Invoking producer Lambda..."
echo '{}' > /tmp/event.json
$AWS lambda invoke   --function-name lab_lambda_producer   --payload file:///tmp/event.json   /tmp/output.txt
cat /tmp/output.txt

echo "✉️ Sending test message to SQS..."
QURL=$($AWS sqs get-queue-url --queue-name lab-sqs-queue --query 'QueueUrl' --output text)
$AWS sqs send-message --queue-url $QURL --message-body '{"test":"hello"}'

echo "📈 Fetching SQS metrics..."
$AWS cloudwatch get-metric-statistics   --namespace AWS/SQS   --metric-name ApproximateNumberOfMessagesVisible   --dimensions Name=QueueName,Value=lab-sqs-queue   --start-time $(date -u -d '-5 minutes' '+%Y-%m-%dT%H:%M:00Z')   --end-time   $(date -u '+%Y-%m-%dT%H:%M:00Z')   --period 60 --statistics Average

echo "📊 Describing CloudWatch Dashboard..."
$AWS cloudwatch describe-dashboards --dashboard-names Lab-Monitoring-Dashboard

echo "✅ Verification complete!"
