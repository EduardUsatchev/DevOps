import json
import boto3
import os

def lambda_handler(event, context):
    localstack_endpoint = f"http://{os.getenv('LOCALSTACK_HOSTNAME', 'host.docker.internal')}:4566"
    secret_name = "MyDatabaseSecret"

    client = boto3.client('secretsmanager', endpoint_url=localstack_endpoint)

    secret = client.get_secret_value(SecretId=secret_name)
    secret_data = json.loads(secret['SecretString'])

    return {
        'statusCode': 200,
        'body': json.dumps(f"Retrieved secret: {secret_data}")
    }
