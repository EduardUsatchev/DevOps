
.. _constrain.ConstraintsUnion:

.. |Constraint| replace:: ConstraintsUnion

Constraints union
-----------------

.. autoclass:: pyasn1.type.constraint.ConstraintsUnion(*constraints)
   :members:
