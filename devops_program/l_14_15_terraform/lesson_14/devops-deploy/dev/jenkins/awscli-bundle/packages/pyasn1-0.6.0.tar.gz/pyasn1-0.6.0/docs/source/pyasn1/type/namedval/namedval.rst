
.. _namedval.NamedValues:

.. |NamedValues| replace:: NamedValues

|NamedValues|
-------------

The |NamedValues| class associates human-friendly names to a set of numbers
or bits.

.. autoclass:: pyasn1.type.namedval.NamedValues
   :members:
