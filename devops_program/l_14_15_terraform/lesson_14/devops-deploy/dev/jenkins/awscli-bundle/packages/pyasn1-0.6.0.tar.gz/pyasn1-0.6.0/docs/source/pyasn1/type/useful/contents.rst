
.. _type.useful:

Useful types
------------

Some assorted utility ASN.1 types belong to the *useful* group.
These types are all scalar.

.. toctree::
   :maxdepth: 2

   /pyasn1/type/useful/objectdescriptor
   /pyasn1/type/useful/generalizedtime
   /pyasn1/type/useful/utctime
