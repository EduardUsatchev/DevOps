:orphan:

Martin Luther King Day: Solution
================================

Presented here is a solution to the :ref:`Martin Luther King Day exercises <mlk-day-exercise>`.


.. include:: mlk_day_rrule_solution.py
   :code: python3

